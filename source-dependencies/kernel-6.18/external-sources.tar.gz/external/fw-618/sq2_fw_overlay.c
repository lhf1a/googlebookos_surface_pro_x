// SPDX-License-Identifier: GPL-2.0-only
#include <linux/module.h>
#include <linux/of.h>
#include <asm/virt.h>
#include "overlay.h"
static bool allow;
module_param(allow, bool, 0400);
static int id = -1;
static int __init start(void)
{
 struct device_node *np;
 bool valid;
 int ret;
 if (!allow || !is_kernel_in_hyp_mode() ||
     !of_machine_is_compatible("microsoft,surface-pro-x") ||
     !of_machine_is_compatible("qcom,sc8180x")) return -EPERM;
 np = of_find_node_by_path("/soc@0/iommu@15000000");
 valid = np && np->phandle == 0x2d &&
         of_device_is_compatible(np, "qcom,sc8180x-smmu-500");
 of_node_put(np);
 if (!valid) return -EINVAL;
 np = of_find_node_by_path("/soc@0/venus-sq2@aa00000");
 valid = np && of_device_is_compatible(np, "microsoft,sq2-venus-lab");
 of_node_put(np);
 if (!valid) return -ENODEV;
 np = of_find_node_by_path("/soc@0/venus-sq2@aa00000/video-firmware");
 if (np) { of_node_put(np); return -EEXIST; }
 ret = of_overlay_fdt_apply(overlay, sizeof(overlay), &id, NULL);
 if (ret) return ret;
 __module_get(THIS_MODULE);
 pr_info("SQ2_FW_OVERLAY id=%d sid=2342 resident_until_reboot NO_CPU_START\n", id);
 return 0;
}
module_init(start);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Opt-in SQ2 EL2 firmware SID2342 candidate child");
