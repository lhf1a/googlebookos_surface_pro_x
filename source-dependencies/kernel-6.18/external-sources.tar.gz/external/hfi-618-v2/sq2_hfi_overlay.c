// SPDX-License-Identifier: GPL-2.0-only
#include <linux/module.h>
#include <linux/of.h>
#include "overlay.h"
#include "sq2-overlay-phandle.h"
static bool allow;
module_param(allow, bool, 0400);
static int id = -1;
static bool check(const char *path, u32 ph) {
 struct device_node *n = of_find_node_by_path(path);
 bool ok = n && n->phandle == ph;
 of_node_put(n); return ok;
}
static int bind_videocc(void) {
 struct device_node *n=of_find_node_by_path("/soc@0/clock-controller@ab00000");
 u32 clocks, resets, domains, live=0;
 bool valid=n && of_device_is_compatible(n,"qcom,sc8180x-videocc") &&
  !of_property_read_u32(n,"#clock-cells",&clocks) && clocks==1 &&
  !of_property_read_u32(n,"#reset-cells",&resets) && resets==1 &&
  !of_property_read_u32(n,"#power-domain-cells",&domains) && domains==1;
 if (valid) live=n->phandle;
 of_node_put(n);
 if (!valid || sq2_overlay_rebind(overlay,sizeof(overlay),videocc_offsets,
     ARRAY_SIZE(videocc_offsets),4096,live)) return -EINVAL;
 pr_info("SQ2_HFI_VIDEOCC phandle=%x references=%zu\n",live,ARRAY_SIZE(videocc_offsets));
 return 0;
}
static int __init start(void) {
 struct device_node *n;
 int ret;
 if (!allow || !of_machine_is_compatible("microsoft,surface-pro-x")) return -EPERM;
 if (!check("/soc@0/clock-controller@100000", 44)) return -EINVAL;
if (!check("/soc@0/iommu@15000000", 45)) return -EINVAL;
if (!check("/soc@0/interconnect@1500000", 47)) return -EINVAL;
if (!check("/soc@0/interconnect@9680000", 5)) return -EINVAL;
if (!check("/soc@0/interconnect@1740000", 107)) return -EINVAL;
if (!check("/interconnect-mc-virt", 6)) return -EINVAL;
 { u32 parent;
 n = of_find_node_by_path("/");
 ret = n ? of_property_read_u32(n, "interrupt-parent", &parent) : -ENODEV;
 of_node_put(n); if (ret || parent != 1) return -EINVAL; }
 ret=bind_videocc(); if (ret) return ret;
 n = of_find_node_by_path("/soc@0/venus-sq2@aa00000");
 if (n) { of_node_put(n); return -EEXIST; }
 n = of_find_node_by_path("/soc@0/iris1-hfi@aa00000");
 if (n) { of_node_put(n); return -EEXIST; }
 ret = of_overlay_fdt_apply(overlay, sizeof(overlay), &id, NULL);
 if (ret) return ret;
 __module_get(THIS_MODULE);
 pr_info("SQ2_HFI_OVERLAY id=%d resident_until_reboot NO_FIRMWARE\n", id);
 return 0;
}
module_init(start);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("SQ2 temporary dedicated video SMMU consumer; no firmware");
